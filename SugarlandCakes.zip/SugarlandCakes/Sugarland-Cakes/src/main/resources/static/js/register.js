
var check = function(event) {
    if (document.getElementById('password').value !=
    document.getElementById('confirmPassword').value) {
        alert("Password entered do not match")
        event.preventDefault();
        return false
    }
}
