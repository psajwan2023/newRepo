package com.project.SugarlandCakes.service;

import com.project.SugarlandCakes.model.CustomUserDetail;
import com.project.SugarlandCakes.model.Role;
import com.project.SugarlandCakes.model.User;
import com.project.SugarlandCakes.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;
import java.util.List;

@Service
public class CustomUserDetailService implements UserDetailsService {

    @Autowired
    UserRepository userRepository;

  /*  @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Optional<User> user = userRepository.findUserByEmail(email);
                user.orElseThrow(() -> new UsernameNotFoundException("Invalid Username"));
        return user.map(CustomUserDetail::new).get();
    }*/

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> userOptional = userRepository.findUserByEmail(username);
        if(userOptional.isEmpty())
        {
            throw new UsernameNotFoundException("User doesn't exist");
        }
        else {
            User user = userOptional.get();
            List<Role> roleList = user.getRoles();
            return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
                    mapRolesToAuthorities(roleList));
        }
    }

    private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles){
        Collection<? extends GrantedAuthority>
                mapRoles = roles.stream().map( role -> new SimpleGrantedAuthority(role.getName())).toList();

        return mapRoles;
    }
}
