package com.project.SugarlandCakes.repository;

import com.project.SugarlandCakes.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer> {
}
