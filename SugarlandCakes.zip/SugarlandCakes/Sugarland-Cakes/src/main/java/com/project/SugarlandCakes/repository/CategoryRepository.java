package com.project.SugarlandCakes.repository;

import com.project.SugarlandCakes.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Integer> {

}
