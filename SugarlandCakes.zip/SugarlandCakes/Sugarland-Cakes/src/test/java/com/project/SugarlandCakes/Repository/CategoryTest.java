package com.project.SugarlandCakes.Repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.project.SugarlandCakes.model.Category;
import com.project.SugarlandCakes.repository.CategoryRepository;
import org.aspectj.lang.annotation.After;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;

import java.lang.reflect.Method;

@SpringBootTest
public class CategoryTest {

    @Autowired
    private CategoryRepository categoryRepository;
    private Category category ;

    @Test
    public void testCategoryEntity() {
        category = new Category();
        category.setName("Nitin");
        categoryRepository.save(category);

        Category savedCategory = categoryRepository.findById(category.getId()).orElse(null);

        assertEquals("XXXX", savedCategory.getName());
    }

    @AfterEach
    public void deleteData(){
        categoryRepository.delete(category);
    }
}
