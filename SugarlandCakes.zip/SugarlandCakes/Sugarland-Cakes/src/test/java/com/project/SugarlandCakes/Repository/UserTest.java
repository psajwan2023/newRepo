package com.project.SugarlandCakes.Repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.project.SugarlandCakes.model.Role;
import com.project.SugarlandCakes.model.User;
import com.project.SugarlandCakes.repository.RoleRepository;
import com.project.SugarlandCakes.repository.UserRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;

@SpringBootTest
public class UserTest {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;
    Role role;
    User user;

    @Test
    public void testUserEntity() {
        role = new Role();
        role.setName("ROLE_MANAGER");
        roleRepository.save(role);

        ArrayList roleList = new ArrayList<Role>();

        user = new User();
        user.setFirstName("Prachi");
        user.setLastName("Sajwan");
        user.setEmail("abc@gmail.com");
        user.setPassword("password");
        roleList.add(role);
        user.setRoles(roleList);
        userRepository.save(user);

        User savedUser = userRepository.findById(user.getId()).orElse(null);

        assertEquals("Prachi", savedUser.getFirstName());
        assertEquals("ROLE_MANAGER", savedUser.getRoles().get(0).getName());
    }

    @AfterEach
    public void deleteData() {
        userRepository.delete(user);
        roleRepository.delete(role);
    }
}
