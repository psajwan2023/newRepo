package com.project.SugarlandCakes.Repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.project.SugarlandCakes.model.Role;
import com.project.SugarlandCakes.repository.RoleRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.beans.factory.annotation.Autowired;

@SpringBootTest
public class RoleTest {

    @Autowired
    private RoleRepository roleRepository;
    private Role role;

    @Test
    public void testRoleEntity() {
        role = new Role();
        role.setName("ROLE_STOREOWNER");
        roleRepository.save(role);
        Role savedRole = roleRepository.findById(role.getId()).orElse(null);
        assertEquals("ROLE_STOREOWNER", savedRole.getName());
    }

    @AfterEach
    public void deleteData() {
        roleRepository.delete(role);
    }
}

