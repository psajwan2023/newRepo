package com.project.SugarlandCakes.Repository;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.project.SugarlandCakes.model.Category;
import com.project.SugarlandCakes.model.Product;
import com.project.SugarlandCakes.repository.CategoryRepository;
import com.project.SugarlandCakes.repository.ProductRepository;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@SpringBootTest
public class ProductTest {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;
    Category category;
    Product product;

    @Test
    public void testProductEntity() {
        category = new Category();
        category.setName("Test Category XX");
        categoryRepository.save(category);

        product = new Product();
        product.setName("Test Product XX");
        product.setCategory(category);
        product.setPrice(10.0);
        product.setWeight(0.5);
        product.setDescription("Test Product Description XXX");
        product.setImageName("test.jpg");
        productRepository.save(product);

        Product savedProduct = productRepository.findById(product.getId()).orElse(null);

        assertEquals("Test Product XX", savedProduct.getName());
        assertEquals(category.getId(), savedProduct.getCategory().getId());
    }
    @Test
    public void testProductByCategory(){
        List prodByCategory = productRepository.findAllByCategory_Id(category.getId());
        assertTrue(prodByCategory.contains(product));
    }

    @AfterEach
    public void deleteData(){
        productRepository.delete(product);
        categoryRepository.delete(category);
    }
}
