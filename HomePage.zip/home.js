function redirectToSignIn() {
    
    window.location.href = "C:\Users\\14803\Desktop\SBA\SignUpLoginPage\SignUp.html"; 
}
