function validateLogin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var errorMessage = document.getElementById("error-message");
    var successMessage = document.getElementById("success-message");

    
    if (username === "user" && password === "password") {
        errorMessage.textContent = "";
        successMessage.textContent = "Login successful! Redirecting...";
        
    } else {
        successMessage.textContent = "";
        errorMessage.textContent = "Invalid username or password. Please try again.";
    }
}
