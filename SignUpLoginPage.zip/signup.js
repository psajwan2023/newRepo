const signupBtn = document.getElementById("signupBtn");
const modal = document.getElementById("myModal");
const modalMessage = document.getElementById("modal-message");
const closeModal = document.querySelector(".close");

signupBtn.addEventListener ("click", function() {
    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const email = document.getElementById("signupEmail").value;
    const password = document.getElementById("signupPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;


    if (password !== confirmPassword) {
        modalMessage.textContent = "Passwords do not match. Please try again.";
        modal.style.display = "block";
        return;
    }

    // Email validation regular expression
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Password validation regular expression: Minimum 8 characters, at least one uppercase letter, one lowercase letter, one number, and one special character
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    

    if (!emailRegex.test(email)) {
        modalMessage.textContent = "Invalid email address. Please enter a valid email.";
        modal.style.display = "block";
        return;
    }
    
    if (!passwordRegex.test(password)) {
        modalMessage.textContent = "Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character.";
        modal.style.display = "block";
        return;
    }

    modalMessage.textContent = "Sign Up Successful!" ;
    modal.style.display= "block";

   
    });

    closeModal.addEventListener("click", function() {
        modal.style.display = "none";
    });
    
    window.addEventListener("click", function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });


