This project allows users to create and manage their resumes and cover letters through a user-friendly web application.

This front-end project aims to create a user interface for an online resume builder. It includes the following key features:

Login Page: Users can log in to access their resume and cover letter data.
Signup Page: New users can create an account to start using the platform.
Home Page: With the home page, user can select various option provided in dropdown menu for resume and cover letter.

later more pages can added....

Prerequisites:

Before you begin, ensure you have the following tools installed:
node.js or
VS studio

Technologies Used:

The project is built using the following technologies:

JavaScript library for building user interfaces.
HTML and CSS for structuring and styling the application.

